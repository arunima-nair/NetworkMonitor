package com.network.monitor;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.nio.file.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;
import java.util.stream.Collectors;

public class Monitor {
    private static final String INPUT_DIR = "./input";
    private static final String OUTPUT_DIR = "./output";
    private static final Set<String> processedRecords = ConcurrentHashMap.newKeySet();
    private static final Map<String, Integer> domainCountMap = new ConcurrentHashMap<>();

    public static void main(String[] args) throws Exception {
        // Create output directory if it doesn't exist
    	Files.createDirectories(Paths.get(INPUT_DIR));
        Files.createDirectories(Paths.get(OUTPUT_DIR));

        // Start directory watcher
        Thread watcherThread = new Thread(() -> watchDirectory());
        watcherThread.start();

        // Start 1-minute scheduler
        ScheduledExecutorService scheduler = Executors.newScheduledThreadPool(1);
        scheduler.scheduleAtFixedRate(() -> writeTopDomains(), 1, 1, TimeUnit.MINUTES);
        while (true) {
            Thread.sleep(1000);
        }
    }

    private static void watchDirectory() {
    	  System.out.println("Starting watchDirectory()...");
        try {
            WatchService watchService = FileSystems.getDefault().newWatchService();
            Paths.get(INPUT_DIR).register(watchService, StandardWatchEventKinds.ENTRY_CREATE);

            System.out.println("Watching directory: " + INPUT_DIR);

            while (true) {
                WatchKey key = watchService.take();

                for (WatchEvent<?> event : key.pollEvents()) {
                    WatchEvent.Kind<?> kind = event.kind();

                    if (kind == StandardWatchEventKinds.ENTRY_CREATE) {
                        Path filename = (Path) event.context();
                        File file = new File(INPUT_DIR + "/" + filename);

                        // Wait until file is stable (fully copied)
                        waitForFileCopy(file);
                        System.out.println("Files copying completed!! " );
                        // Process CSV file
                        processFile(file);
                        System.out.println("Processing file completed!! " );
                    }
                }
                key.reset();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void waitForFileCopy(File file) throws InterruptedException {
        long lastSize = -1;
        while (true) {
            long currentSize = file.length();
            if (currentSize == lastSize) {
                break;
            }
            lastSize = currentSize;
            Thread.sleep(500); // check every 500ms
        }
    }

    private static void processFile(File file) {
        System.out.println("Processing file: " + file.getName());

        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String header = reader.readLine(); // skip header

            String line;
            while ((line = reader.readLine()) != null) {
                String[] tokens = line.split(",");
                if (tokens.length < 6) continue;

                String timestamp = tokens[0];
                String srcIp = tokens[1];
                String dstIp = tokens[3];
                String domain = tokens[5];

                // Unique key
                String recordKey = timestamp + srcIp + dstIp + domain;

                // Deduplication
                if (processedRecords.contains(recordKey)) {
                    continue;
                }

                processedRecords.add(recordKey);

                // Aggregation
                domainCountMap.merge(domain, 1, Integer::sum);
                
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void writeTopDomains() {
        try {
            // Sort top 10
        	 System.out.println("Write Top 10 Domains started!! " );
            List<Map.Entry<String, Integer>> topDomains = domainCountMap.entrySet().stream()
                    .sorted((a, b) -> b.getValue().compareTo(a.getValue()))
                    .limit(10)
                    .collect(Collectors.toList());

            // Prepare output
            String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
            StringBuilder sb = new StringBuilder();
            sb.append("# Top 10 Domains - ").append(timestamp).append("\n");

            int rank = 1;
            for (Map.Entry<String, Integer> entry : topDomains) {
                sb.append(rank).append(". ").append(entry.getKey())
                        .append(" - ").append(entry.getValue()).append(" connections\n");
                rank++;
            }

            // Write to file
            String outputFileName = OUTPUT_DIR + "/top_domains_" + System.currentTimeMillis() + ".txt";
            Files.write(Paths.get(outputFileName), sb.toString().getBytes());

            System.out.println("Written top domains to: " + outputFileName);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
